package edac.dao;
import java.sql.Connection;


import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class SetupByStepDao {
	public static String DB_DRIVER="com.mysql.cj.jdbc.Driver";
    public static final String DB_URL="jdbc:mysql://localhost:3306/edac";
     public static final String DB_USER="root";
     public static String DB_PASSWORD="edac2020";
     
     
     public void checkConnection() {
    	 try(Connection con=DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);){
    		 Class.forName(DB_DRIVER);
    		 System.out.println("Success try with resource!!");
    		 
    		
    	 }
    	 catch(Exception e) {
    		 e.printStackTrace();
    		 
    	 }
     }

public boolean createUser(User user) {
	try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);) {
		Class.forName(DB_DRIVER);
		
		String sql = "INSERT INTO USERS (username, email,password,mobile) VALUES (?, ?, ?, ?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, user.getUsername());
		ps.setString(2, user.getEmail());
		ps.setString(3, user.getPassword());
		ps.setString(4, user.getMobile());
		
		ps.executeUpdate();
		System.out.println("Insert Success");
		
		return true;
	} catch (Exception e) {
		e.printStackTrace();
		return false;
	}
}



public static void main(String[] args) {
	SetupByStepDao dao = new SetupByStepDao();
	
	
	
	User user = new User("mumbai2", "mumbai2@gmail.com", "adsfa", "adsfa");
	dao.createUser(user);
}


	
}
 

