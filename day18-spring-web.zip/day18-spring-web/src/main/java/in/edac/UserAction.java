package in.edac;

public class UserAction {
	
	public String helloWorld() {
		return "HelloWorld";
	}
	
	
	
	

}
