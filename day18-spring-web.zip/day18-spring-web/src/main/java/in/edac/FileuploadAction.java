package in.edac;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("file-action")
public class FileuploadAction {
	
	@GetMapping("/")
	public String fileAction() {
		return "File Action";
		
		
	}
	@GetMapping("/1")
	public String fileActionV1() {
		return "File Action V1";
		
	
	}
	

}
