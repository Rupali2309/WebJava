package in.edac;

import org.springframework.stereotype.Component;

@Component("obj1")
public class UserDao {

	
}
