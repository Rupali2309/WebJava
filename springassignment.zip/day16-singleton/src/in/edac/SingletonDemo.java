package in.edac;

public class SingletonDemo {
	public static void main(String[] args) {
		UserDao ref1 = UserDao.getInstance();
		System.out.println(ref1);
		
		
		UserDao ref2 = UserDao.getInstance();
		System.out.println(ref2);
	}

}
