package in.edac;

import java.util.List;

import org.hibernate.internal.build.AllowSysOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day16SpringJpaApplication implements CommandLineRunner {

	@Autowired
	private UserRepository userRepository;
	
	
	public static void main(String[] args) {
		SpringApplication.run(Day16SpringJpaApplication.class, args);
		
		
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		System.out.println("Hello spring ,this is run method");
	
	     //queryDemo();
	     create();
	}
	


 public void queryDemo() {
	 
	 List<User>list = userRepository.findAll();
	list.stream().map(User::getUserName).forEach(System.out::println);
	

	List<User> list1 = userRepository.findByUsernameOrEmail("Rupali", "r@gmail.com");
	list1.stream().map(User::getUserName).forEach(System.out::println);
	
 }
 
 public void delete() {
	 userRepository.deleteById(1);
 }
 public void findAndUIpdate() {
	 User user = userRepository.findById(2).get();
	 user.setUserName("Rupa");
	 userRepository.save(user);
 }
 public void update() {
	 User user = new User();
	 user.setId(1);
	 user.setUserName("Rupali kale");
	 userRepository.save(user);
 }
 public void create() {
	 User user  =  new User("Rupali","12345","r@gmail.com","3456789");
	 userRepository.save(user);
	 
	 
	 
 }
}