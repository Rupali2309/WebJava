package servlet;

public class Student {

}
