package in.edac;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/sample")
public class SampleAction {
	
	public String homeView() {
		return "home";
	}
@GetMapping("/home-view-v1")
	public ModelAndView homeViewV1() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		return mv;
	}

@GetMapping("/home-view-v2")
public ModelAndView homeview2() {
	
	ModelAndView mv = new ModelAndView();
	mv.setViewName("home");
	String title = ("Hello Mumbai");
	return mv;
	
}

@GetMapping("home-view-v3")
public ModelAndView homeViewV3() {
	ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		
		String title = "Hello Mumbai";
		mv.addObject("title", title);
		
		List<String> cityList = Arrays.asList("Delhi", "Kolkata", "Mumbai", "Chennai");
		mv.addObject("cityList", cityList);
		
		return mv;
	}
}

