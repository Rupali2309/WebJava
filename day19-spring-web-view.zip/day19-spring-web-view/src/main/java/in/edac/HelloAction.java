package in.edac;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hello")
public class HelloAction {
	
	@GetMapping("/")
	public String sayHello() {
		return "Helloo";
		
	}
	@GetMapping("/1")
	public String sayHi() {
		return "hi";
	}
	
	@GetMapping("/2")
	public String Helloo() {
		return "hii";
	}
	
	

}
